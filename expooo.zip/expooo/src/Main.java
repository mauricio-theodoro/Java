import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Carro carro1 = new Carro();
        carro1.setId(1);
        carro1.setFabricante("BMW");
        carro1.setModelo("X6");
        carro1.setCor("White");
        carro1.setAnoFabricacao(2024);
        carro1.setnPlaca("G7EW334");
        carro1.setQtdPortas(5);
        carro1.setLugares(5);
        System.out.println(carro1.toString());
        /*System.out.println("id: "+ carro1.getId()+"\n"+"Fabricante: "+carro1.getFabricante()+"\n"+
                "Modelo: "+carro1.getModelo()+"\n"+
                "Cor: "+ carro1.getCor()+"\n"+"Ano de Fabricação: "+carro1.getAnoFabricacao()+"\n"+
                "Lugares: "+carro1.getLugares()+"\n"+"Placa: "+ carro1.getnPlaca()+"\n"+
                "Portas: "+ carro1.getQtdPortas()+"\n");*/
    }
}