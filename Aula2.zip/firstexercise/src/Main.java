import java.io.IOException;
import java.util.Scanner;
public class Main{
    public static void main(String[] args) {
        int par = 0;
        int impar = 0;
        int opcao =-1;
        Scanner in = new Scanner(System.in);
        System.out.println("Entre com um número:");
        System.out.println("Digite 0 para sair:");
        do {
            opcao = in.nextInt();
            if (opcao % 2 == 0){
                par ++;
            }
            else {
                impar ++;
            }
        }while (opcao!=0);
        System.out.println("os numeros pares são:"+ par);
        System.out.println("os numeros impares são:"+ impar);5
    }
}