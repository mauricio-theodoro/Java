import java.io.IOException;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int num = 1;
        int num2 =0;
        int opcao = -1;
        Scanner scn = new Scanner(System.in);
        do {
            System.out.println("Digite o" + num +" para fazer a contagem:");
            opcao = scn.nextInt();
                num++;
                num2 += num;

        }while(opcao !=-1);
        num--;
        System.out.printf("A quantidade de numeros digitados são:"+ num);
        System.out.printf("a soma dos numeros são:", num2);
    }
}