import java.io.IOException;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Double soma = 0.0;
        Double nota = 0.0;
        Scanner scn = new Scanner(System.in);
        for (int i = 1; i<= 3; i++) {
            System.out.println("Entre com 3 numeros:");
            nota = scn.nextDouble();
            soma = soma + nota;
        }
        System.out.println("A nota é:"+ soma);
        System.out.println("A media das notas é:" + (soma/3));
    }
}